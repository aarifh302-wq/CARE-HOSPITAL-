# Launches the CarePoint Marketing Analytics Dashboard in your default browser
$dashboardPath = Join-Path $PSScriptRoot "dashboard.html"
Write-Host "Opening CarePoint Marketing Dashboard..." -ForegroundColor Green
Start-Process $dashboardPath
