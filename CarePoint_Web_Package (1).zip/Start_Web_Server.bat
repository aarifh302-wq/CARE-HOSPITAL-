@echo off
title CarePoint Hospital - Local Web Server (http://localhost:8080)
echo ========================================================
echo   CarePoint Hospital - Web Server Starting...
echo ========================================================
echo.
echo   All 3 Applications in ONE URL:
echo   - Master Unified Portal: http://localhost:8080/
echo     [1] 37-Slide Strategic Presentation
echo     [2] Marketing Analytics & Funnel Dashboard
echo     [3] CarePoint Patient Appointment Website
echo.
echo   Opening Unified Suite in your default browser...
echo   (Keep this window open to keep the URL active)
echo ========================================================
echo.

start "" "http://localhost:8080/"

powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1" -Port 8080
pause
