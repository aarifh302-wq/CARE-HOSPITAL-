﻿# Setup CarePoint Hospital Desktop Shortcuts
$targetDir = "C:\Users\aarif\.gemini\antigravity\scratch\carepoint-hospital-jaipur"
$dashboardHtml = Join-Path $targetDir "dashboard.html"
$websiteHtml = Join-Path $targetDir "index.html"

# Primary Desktop Paths
$desktopPaths = @(
    "C:\Users\aarif\Desktop",
    "C:\Users\aarif\OneDrive\Desktop"
)

$targetDesktop = $null
foreach ($p in $desktopPaths) {
    if (Test-Path $p) {
        $targetDesktop = $p
        break
    }
}

if (-not $targetDesktop) {
    $targetDesktop = "C:\Users\aarif\Desktop"
}

Write-Host "Target Desktop Directory: $targetDesktop" -ForegroundColor Cyan

# 1. Create .bat launcher on Desktop for 100% reliable execution
$batContent = @"
@echo off
title CarePoint Hospital - Marketing Analytics Dashboard
echo ========================================================
echo   Launching CarePoint Marketing Analytics Dashboard...
echo ========================================================
start "" "$dashboardHtml"
exit
"@
$batPath = Join-Path $targetDesktop "Launch_CarePoint_Dashboard.bat"
Set-Content -Path $batPath -Value $batContent -Encoding ASCII
Write-Host "Created Desktop Batch Launcher: $batPath" -ForegroundColor Green

# 2. Create Patient Website .bat launcher on Desktop
$webBatContent = @"
@echo off
title CarePoint Hospital - Patient Appointment Website
echo ========================================================
echo   Launching CarePoint Patient Appointment Website...
echo ========================================================
start "" "$websiteHtml"
exit
"@
$webBatPath = Join-Path $targetDesktop "Launch_CarePoint_Website.bat"
Set-Content -Path $webBatPath -Value $webBatContent -Encoding ASCII
Write-Host "Created Desktop Website Launcher: $webBatPath" -ForegroundColor Green

# 3. Create rich Windows .lnk Shortcut using WScript.Shell
try {
    $wshShell = New-Object -ComObject WScript.Shell
    
    # Dashboard Shortcut
    $shortcutPath = Join-Path $targetDesktop "CarePoint Marketing Dashboard.lnk"
    $shortcut = $wshShell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $dashboardHtml
    $shortcut.WorkingDirectory = $targetDir
    $shortcut.Description = "CarePoint Hospital Jaipur — Digital Marketing & Analytics Dashboard"
    $shortcut.Save()
    Write-Host "Created Windows Shortcut: $shortcutPath" -ForegroundColor Green

    # Website Shortcut
    $webShortcutPath = Join-Path $targetDesktop "CarePoint Patient Website.lnk"
    $webShortcut = $wshShell.CreateShortcut($webShortcutPath)
    $webShortcut.TargetPath = $websiteHtml
    $webShortcut.WorkingDirectory = $targetDir
    $webShortcut.Description = "CarePoint Hospital Jaipur — Patient Appointment Enquiry Website"
    $webShortcut.Save()
    Write-Host "Created Windows Shortcut: $webShortcutPath" -ForegroundColor Green
} catch {
    Write-Warning "Could not create .lnk shortcut via COM; .bat launchers are ready."
}

# 4. Launch the dashboard immediately
Write-Host "Launching dashboard now..." -ForegroundColor Yellow
Start-Process $dashboardHtml
Write-Host "Successfully configured desktop shortcuts and launched dashboard!" -ForegroundColor Green
