# CarePoint Hospital, Jaipur — Appointment Enquiry Website

A fast-loading, mobile-first single-page appointment enquiry website built specifically for **CarePoint Hospital, Jaipur**.

---

## 🌟 Highlights & Key Features

- **Teal #0F766E Brand Identity**: Primary brand teal (`#0F766E`) themed with complementary tints, modern slate typography, and high-contrast emergency accents.
- **Poppins Typography**: Loaded with Google Fonts preconnection and `font-display: swap` for instant rendering and readability.
- **Mobile-First Layout**: Optimized touch targets (minimum 44px), thumb-friendly sticky bottom bar with instant 1-tap call & WhatsApp triggers.
- **Zero Heavy Dependencies / Fast Loading**: Pure HTML5, modular CSS3, and vanilla ES6 JavaScript. No heavy JS frameworks or bulky CSS libraries — loads in under 100ms.
- **Privacy & Compliance First**: Prominent visible notice: **"Do not enter medical details in this form."** ensures patient data privacy compliance.
- **Google Analytics 4**: Configured with standard `gtag.js` and custom lead tracking events (`appointment_enquiry_submitted` and `generate_lead`). **No other external trackers or third-party cookies.**
- **WhatsApp Appointment Enquiry Generator**: Submitting the form validates inputs and immediately opens official WhatsApp with a structured, pre-formatted booking enquiry addressed to the hospital reception.

---

## 📋 Page Sections

1. **Top Emergency Bar**:
   - 24x7 Emergency Trauma response indicator & clickable call hotline (`+91 141 234 5678`).
   - Location indicator: *Malviya Nagar, Jaipur*.
2. **Header & Navigation**:
   - CarePoint Hospital logo with clean SVG cross emblem.
   - Smooth-scrolling anchor links: Specialities, Doctors, Hours & Emergency, Location, and "Book Appointment" CTA button.
   - Mobile responsive slide-down drawer menu.
3. **Hero Section**:
   - Compelling headline and clinical excellence badge.
   - Dual CTAs: "Book an Appointment" & "24x7 Emergency Call".
   - Key trust metrics: 25+ Years, 50+ Doctors, 24x7 ICU, 100k+ Patients.
   - Hospital architectural vector graphic and active OPD indicator.
4. **6 Core Speciality Cards**:
   - **Cardiology & Heart Care** (Cath Lab, Angioplasty, Echo)
   - **Orthopaedics & Joint Care** (Knee & Hip Replacement, Arthroscopy)
   - **Neurology & Neurosurgery** (Golden Hour Stroke Unit, Spine Surgery)
   - **Paediatrics & Neonatology** (Level-3 NICU, Vaccinations)
   - **Obstetrics & Gynaecology** (Maternity Suites, Painless Delivery)
   - **General & Laparoscopic Surgery** (Keyhole Gallbladder, Hernia, Laser Proctology)
   - *Interactive feature*: Clicking "Book for [Speciality]" automatically jumps to the form, selects the speciality, and focuses the Name field.
5. **Senior Doctor Cards**:
   - Dr. Arvind K. Sharma (Chief Cardiologist - AIIMS Alumnus)
   - Dr. Sunita Meena (Head of Obstetrics & Gynaecology)
   - Dr. Vikramaditya Rathore (Joint Replacement & Orthopaedics)
   - Dr. Rajesh Singhania (Chief Neurosurgeon)
   - Dr. Priyanshi Mathur (Chief Paediatrician & Neonatologist)
   - Dr. Neha Agarwal (Laparoscopic Surgeon)
   - *Interactive feature*: Clicking "Consult Dr. [Name]" pre-fills the doctor and speciality into the booking form.
6. **Opening Hours & 24x7 Emergency Section**:
   - High-contrast 24x7 Emergency Trauma & Ambulance card with direct call links.
   - Department schedules: Emergency (24h/7d), OPD (Mon-Sat 8AM-8PM), Sunday Speciality OPD (9AM-1PM), Labs (24x7 sample collection), and Visiting hours.
7. **Appointment Enquiry Form**:
   - **Visible Privacy Badge**: *"Do not enter medical details in this form."*
   - Patient Full Name
   - Phone / WhatsApp (+91 10-digit Indian mobile validation)
   - Speciality dropdown (6 specialities + General Medicine)
   - Preferred Date (HTML5 date picker constrained to today or future dates)
   - Preferred Time Slot (Morning / Afternoon / Evening)
   - Doctor Preference (Auto-populated or selectable)
   - Optional Message / Logistics notes
   - One-click green WhatsApp submission button + fallback link if popups are blocked.
8. **Jaipur Google Maps Embed & Location Details**:
   - Embedded Google Map centered in Jaipur (Malviya Nagar / JLN Marg).
   - Address details, emergency Gate 1 ramp instructions, valet parking note, and "Get Directions" link.
9. **Footer**:
   - Accreditations: NABH Accredited, NABL Certified Labs, Ayushman Bharat Empanelled.
   - 24x7 Hotlines, quick navigation links, and copyright.
10. **Mobile Sticky Action Bar**:
    - Fixed bottom drawer for smartphones with 1-tap Emergency Call, Book Appointment, and WhatsApp buttons.

---

## 📊 Marketing Analytics & Econometric Dashboard

The project now includes an internal executive growth dashboard: `dashboard.html`.

### How to Easily Open & Change:
1. **1-Click Windows Launcher**:
   - Double-click `Launch_Dashboard.bat` in this folder to open the dashboard in your default browser.
   - Double-click `Launch_Website.bat` to open the public patient appointment booking landing page.
2. **In-Browser Customization ("⚙️ Edit Model Assumptions")**:
   - Click the **"Edit Model Assumptions"** button in the dashboard header to change:
     - Hospital & Doctor names
     - Average OPD ticket (₹2,200) & surgical IPD ticket (₹65,000)
     - Ad budget, CPM, CTR, and conversion rates
   - **Auto-Persistence**: All edits save automatically to browser storage (`localStorage`) so your customized numbers stay active every time you open it!
   - **Export / Import**: Easily export or import model numbers as `.json`.
3. **Log New Social Media Posts**:
   - In the **Meta Social Insights** tab, click **"+ Log New Post"** to add custom reels/posts and see engagement rates recalculate instantly.
4. **Cross-Navigation**:
   - From the patient website (`index.html`), click **"📊 Marketing Dashboard"** in the top navigation.
   - From the dashboard (`dashboard.html`), click **"Live Patient Website"** to switch back and forth.

---

## 🛠️ Configuration & Customization

### 1. Update WhatsApp Number
Open `script.js` and locate line 16:
```javascript
const HOSPITAL_WHATSAPP_NUMBER = "919829012345";
```
Replace `"919829012345"` with your hospital's WhatsApp reception number (country code `91` followed by your 10-digit mobile number, with no spaces, dashes, or `+` sign).

### 2. Update Google Analytics 4 Measurement ID
Open `index.html` and locate line 17:
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-CAREPOINTJP"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-CAREPOINTJP', {
    'anonymize_ip': true,
    'send_page_view': true
  });
</script>
```
Replace `G-CAREPOINTJP` with your real Google Analytics 4 Measurement ID (e.g. `G-XXXXXXXXXX`).

### 3. Update Hospital Emergency Hotlines
Open `index.html` and search for:
- Emergency Phone: `tel:+911412345678` (Update to your hospital landline/hotline)
- Ambulance Phone: `tel:+919829012345`

---

## 🚀 How to Run & Preview

Since this project uses pure semantic web technologies, no build tools or package managers are needed:

1. **Direct browser preview**:
   Double click `index.html` to open it in any web browser (Chrome, Edge, Safari, Firefox).

2. **Local HTTP server** (optional):
   Using Python:
   ```bash
   python -m http.server 8080
   ```
   Then open `http://localhost:8080` in your browser.
