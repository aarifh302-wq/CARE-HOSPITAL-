/**
 * CarePoint Hospital, Jaipur - Interactive Scripts
 * Features: Mobile Nav, Datepicker Min-Date, Speciality Autofill, WhatsApp Enquiry Builder, GA4 Event Dispatch
 */

(function () {
  'use strict';

  // =========================================================================
  // 1. CONFIGURATION
  // =========================================================================
  // Update this to CarePoint Hospital's official WhatsApp reception number
  // Format: Country Code without '+' followed by 10-digit number (e.g. 919829012345)
  const HOSPITAL_WHATSAPP_NUMBER = "919829012345";

  // =========================================================================
  // 2. DOM ELEMENTS
  // =========================================================================
  const mobileNavToggle = document.getElementById('mobileNavToggle');
  const mobileDrawer = document.getElementById('mobileDrawer');
  const appointmentForm = document.getElementById('appointmentEnquiryForm');
  const patientNameInput = document.getElementById('patientName');
  const patientPhoneInput = document.getElementById('patientPhone');
  const specialitySelect = document.getElementById('specialitySelect');
  const preferredDateInput = document.getElementById('preferredDate');
  const preferredSlotSelect = document.getElementById('preferredSlot');
  const doctorPreferenceSelect = document.getElementById('doctorPreference');
  const patientMessageInput = document.getElementById('patientMessage');
  const bookingSuccessBox = document.getElementById('bookingSuccessBox');
  const fallbackWhatsAppAnchor = document.getElementById('fallbackWhatsAppAnchor');
  const currentYearSpan = document.getElementById('currentYear');

  // Error feedback elements
  const nameError = document.getElementById('nameError');
  const phoneError = document.getElementById('phoneError');
  const specialityError = document.getElementById('specialityError');
  const dateError = document.getElementById('dateError');

  // =========================================================================
  // 3. INITIALIZATION & DATE RESTRICTIONS
  // =========================================================================
  document.addEventListener('DOMContentLoaded', () => {
    initFooterYear();
    initDatepickerConstraints();
    initMobileNav();
    initCardQuickBookActions();
    initFormValidation();
  });

  function initFooterYear() {
    if (currentYearSpan) {
      currentYearSpan.textContent = new Date().getFullYear();
    }
  }

  /**
   * Sets minimum date for appointment booking to today's date
   */
  function initDatepickerConstraints() {
    if (!preferredDateInput) return;

    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    const minDate = `${yyyy}-${mm}-${dd}`;

    preferredDateInput.min = minDate;
    // Set default value to tomorrow or today
    preferredDateInput.value = minDate;
  }

  // =========================================================================
  // 4. MOBILE NAVIGATION
  // =========================================================================
  function initMobileNav() {
    if (!mobileNavToggle || !mobileDrawer) return;

    mobileNavToggle.addEventListener('click', () => {
      const isExpanded = mobileNavToggle.getAttribute('aria-expanded') === 'true';
      toggleDrawer(!isExpanded);
    });

    // Close mobile drawer when clicking any link inside it
    const drawerLinks = mobileDrawer.querySelectorAll('a');
    drawerLinks.forEach(link => {
      link.addEventListener('click', () => {
        toggleDrawer(false);
      });
    });

    // Close when clicking outside drawer
    document.addEventListener('click', (event) => {
      if (!mobileDrawer.contains(event.target) && !mobileNavToggle.contains(event.target)) {
        if (mobileDrawer.classList.contains('open')) {
          toggleDrawer(false);
        }
      }
    });
  }

  function toggleDrawer(open) {
    if (open) {
      mobileDrawer.classList.add('open');
      mobileNavToggle.classList.add('active');
      mobileNavToggle.setAttribute('aria-expanded', 'true');
      mobileDrawer.setAttribute('aria-hidden', 'false');
    } else {
      mobileDrawer.classList.remove('open');
      mobileNavToggle.classList.remove('active');
      mobileNavToggle.setAttribute('aria-expanded', 'false');
      mobileDrawer.setAttribute('aria-hidden', 'true');
    }
  }

  // =========================================================================
  // 5. SPECIALITY & DOCTOR CARD QUICK ACTIONS
  // =========================================================================
  function initCardQuickBookActions() {
    // 1. Speciality Card Buttons
    const specialityButtons = document.querySelectorAll('.select-speciality-btn');
    specialityButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const speciality = btn.getAttribute('data-speciality');
        handleQuickSelectSpeciality(speciality);
      });
    });

    // 2. Doctor Card Buttons
    const doctorButtons = document.querySelectorAll('.book-doctor-btn');
    doctorButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const doctorName = btn.getAttribute('data-doctor');
        const speciality = btn.getAttribute('data-speciality');
        handleQuickSelectDoctor(doctorName, speciality);
      });
    });
  }

  function handleQuickSelectSpeciality(specialityName) {
    if (specialitySelect && specialityName) {
      // Find matching option
      for (let i = 0; i < specialitySelect.options.length; i++) {
        if (specialitySelect.options[i].value === specialityName ||
            specialitySelect.options[i].text.toLowerCase().includes(specialityName.toLowerCase())) {
          specialitySelect.selectedIndex = i;
          clearFieldError(specialitySelect, specialityError);
          break;
        }
      }
    }

    scrollToFormAndFocus();
  }

  function handleQuickSelectDoctor(doctorName, specialityName) {
    // Select speciality
    if (specialityName) {
      handleQuickSelectSpeciality(specialityName);
    }

    // Select doctor preference if dropdown exists
    if (doctorPreferenceSelect && doctorName) {
      for (let i = 0; i < doctorPreferenceSelect.options.length; i++) {
        if (doctorPreferenceSelect.options[i].text.includes(doctorName)) {
          doctorPreferenceSelect.selectedIndex = i;
          break;
        }
      }
    }

    scrollToFormAndFocus();
  }

  function scrollToFormAndFocus() {
    const formSection = document.getElementById('appointment-form');
    if (formSection) {
      formSection.scrollIntoView({ behavior: 'smooth' });
    }
    setTimeout(() => {
      if (patientNameInput) {
        patientNameInput.focus();
      }
    }, 450);
  }

  // =========================================================================
  // 6. ENQUIRY FORM VALIDATION & WHATSAPP REDIRECT
  // =========================================================================
  function initFormValidation() {
    if (!appointmentForm) return;

    // Real-time input cleanup & validation
    patientPhoneInput.addEventListener('input', (e) => {
      // Allow only digits
      e.target.value = e.target.value.replace(/\D/g, '').slice(0, 10);
      if (e.target.value.length === 10) {
        clearFieldError(patientPhoneInput, phoneError);
      }
    });

    patientNameInput.addEventListener('input', () => {
      if (patientNameInput.value.trim().length >= 2) {
        clearFieldError(patientNameInput, nameError);
      }
    });

    specialitySelect.addEventListener('change', () => {
      if (specialitySelect.value) {
        clearFieldError(specialitySelect, specialityError);
      }
    });

    // Form submission
    appointmentForm.addEventListener('submit', handleFormSubmit);
  }

  function handleFormSubmit(e) {
    e.preventDefault();

    let isValid = true;
    let firstInvalidInput = null;

    // 1. Name validation
    const nameVal = patientNameInput.value.trim();
    if (!nameVal || nameVal.length < 2) {
      showFieldError(patientNameInput, nameError);
      isValid = false;
      if (!firstInvalidInput) firstInvalidInput = patientNameInput;
    } else {
      clearFieldError(patientNameInput, nameError);
    }

    // 2. Phone validation (Indian 10-digit number starting with 6, 7, 8, or 9)
    const phoneVal = patientPhoneInput.value.trim();
    const phoneRegex = /^[6-9]\d{9}$/;
    if (!phoneRegex.test(phoneVal)) {
      showFieldError(patientPhoneInput, phoneError);
      isValid = false;
      if (!firstInvalidInput) firstInvalidInput = patientPhoneInput;
    } else {
      clearFieldError(patientPhoneInput, phoneError);
    }

    // 3. Speciality validation
    const specialityVal = specialitySelect.value;
    if (!specialityVal) {
      showFieldError(specialitySelect, specialityError);
      isValid = false;
      if (!firstInvalidInput) firstInvalidInput = specialitySelect;
    } else {
      clearFieldError(specialitySelect, specialityError);
    }

    // 4. Date validation
    const dateVal = preferredDateInput.value;
    if (!dateVal) {
      showFieldError(preferredDateInput, dateError);
      isValid = false;
      if (!firstInvalidInput) firstInvalidInput = preferredDateInput;
    } else {
      const selectedDate = new Date(dateVal);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (selectedDate < today) {
        showFieldError(preferredDateInput, dateError);
        isValid = false;
        if (!firstInvalidInput) firstInvalidInput = preferredDateInput;
      } else {
        clearFieldError(preferredDateInput, dateError);
      }
    }

    if (!isValid) {
      if (firstInvalidInput) {
        firstInvalidInput.focus();
      }
      return;
    }

    // Capture other fields
    const slotVal = preferredSlotSelect ? preferredSlotSelect.value : "Any Slot";
    const doctorVal = doctorPreferenceSelect ? doctorPreferenceSelect.value : "Any Available Specialist";
    const messageVal = patientMessageInput ? patientMessageInput.value.trim() : "";

    // Build WhatsApp message
    const formattedDate = formatDateDisplay(dateVal);
    const whatsappMessage = buildWhatsAppMessage({
      name: nameVal,
      phone: phoneVal,
      speciality: specialityVal,
      doctor: doctorVal,
      date: formattedDate,
      slot: slotVal,
      message: messageVal
    });

    const encodedMessage = encodeURIComponent(whatsappMessage);
    const whatsappUrl = `https://wa.me/${HOSPITAL_WHATSAPP_NUMBER}?text=${encodedMessage}`;

    // Track in Google Analytics 4 (Only permitted external tracker)
    trackGA4AppointmentSubmission({
      speciality: specialityVal,
      doctor: doctorVal,
      preferredDate: dateVal
    });

    // Provide user feedback and open WhatsApp
    displaySuccessBanner(whatsappUrl);

    // Open WhatsApp in a new tab/window
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  }

  function showFieldError(inputElem, errorElem) {
    if (inputElem) inputElem.classList.add('input-error');
    if (errorElem) errorElem.classList.add('visible');
  }

  function clearFieldError(inputElem, errorElem) {
    if (inputElem) inputElem.classList.remove('input-error');
    if (errorElem) errorElem.classList.remove('visible');
  }

  /**
   * Constructs the structured WhatsApp enquiry text
   */
  function buildWhatsAppMessage(data) {
    const lines = [
      "🏥 *CarePoint Hospital, Jaipur*",
      "📋 *New Appointment Enquiry*",
      "--------------------------------",
      `👤 *Patient Name:* ${data.name}`,
      `📞 *Contact:* +91 ${data.phone}`,
      `🩺 *Speciality:* ${data.speciality}`,
      `👨‍⚕️ *Doctor Preference:* ${data.doctor}`,
      `📅 *Date:* ${data.date}`,
      `⏰ *Preferred Slot:* ${data.slot}`
    ];

    if (data.message && data.message.length > 0) {
      lines.push(`📝 *Note:* ${data.message}`);
    }

    lines.push("--------------------------------");
    lines.push("🔒 _Note: Medical details omitted per privacy policy._");
    lines.push("Kindly confirm availability and registration details. Thank you!");

    return lines.join("\n");
  }

  /**
   * Helper to format YYYY-MM-DD into readable date (e.g., '16 Nov 2026')
   */
  function formatDateDisplay(isoDateString) {
    try {
      const parts = isoDateString.split('-');
      if (parts.length === 3) {
        const d = new Date(parts[0], parts[1] - 1, parts[2]);
        return d.toLocaleDateString('en-IN', {
          weekday: 'short',
          day: 'numeric',
          month: 'short',
          year: 'numeric'
        });
      }
    } catch (e) {
      // Fallback to raw string
    }
    return isoDateString;
  }

  /**
   * Dispatch Google Analytics 4 Custom Events
   */
  function trackGA4AppointmentSubmission(details) {
    if (typeof window.gtag === 'function') {
      window.gtag('event', 'generate_lead', {
        event_category: 'Hospital Enquiry',
        event_label: details.speciality,
        value: 1
      });

      window.gtag('event', 'appointment_enquiry_submitted', {
        speciality: details.speciality,
        doctor: details.doctor,
        booking_date: details.preferredDate,
        hospital_location: 'Jaipur'
      });
    }
  }

  /**
   * Show feedback modal/banner if popups are blocked or as confirmation
   */
  function displaySuccessBanner(whatsappUrl) {
    if (bookingSuccessBox && fallbackWhatsAppAnchor) {
      fallbackWhatsAppAnchor.href = whatsappUrl;
      bookingSuccessBox.style.display = 'flex';
      bookingSuccessBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }

})();
